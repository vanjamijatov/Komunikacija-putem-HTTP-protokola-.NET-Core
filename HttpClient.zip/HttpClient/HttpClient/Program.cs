﻿using System;
using System.Threading.Tasks;

namespace HttpRestClient
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Choose option:");
            PrintMenu();
            string input = Console.ReadLine();
            if (ValidInput(input))
            {
                await RestClient.SendRequest(int.Parse(input));
            }
            else
            {
                Console.WriteLine("Input not valid!");
            }
        }

        private static void PrintMenu() 
        {
            Console.WriteLine("1 - Send GET request to get all products");
            Console.WriteLine("2 - Send POST request create new product");
            Console.WriteLine("3 - Send GET request with RestSharp to get all products");
            Console.WriteLine("4 - Send POST request with RestSharp create new product");
            Console.Write("Choose option 1-4: ");
        }

        private static bool ValidInput(string input)
        {
            int n;
            bool isNumeric = int.TryParse(input, out n);
            if (isNumeric)
            {
                return n >= 1 && n <= 4;
            }
            else
            {
                return false;
            }
        }
    }
}
