﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HttpRestClient
{
    class ProductDto
    {
        public string Name { get; set; }
        public string Color { get; set; }
        public double Price { get; set; }

        public ProductDto() { }

        public override string ToString()
        {
            return this.Name + "; " + this.Color + "; " + this.Price.ToString();
        }
    }
}
